SECRET_KEY = 'reallypickagoodkeyhere'

DEBUG = False
